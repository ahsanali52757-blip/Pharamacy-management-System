<!DOCTYPE html>
<html>

<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="nav2.css">
<link rel="stylesheet" type="text/css" href="table1.css">
<title>
Reports
</title>
<style>
  /* Add some margin for the search input */
  #searchInput {
  	margin-top: 50px;
    margin-left: 700px;
    margin-bottom: 10px;
    padding: 6px;
    width: 300px;
    font-size: 16px;
  }
</style>
</head>

<body>

    <div class="sidenav">
        <h2 style="font-family:Arial; color:white; text-align:center;"> Zam Zam Pharmacy  </h2>
        <a href="adminmainpage.php">Dashboard</a>
        <button class="dropdown-btn">Inventory
        <i class="down"></i>
        </button>
        <div class="dropdown-container">
            <a href="inventory-add.php">Add New Medicine</a>
            <a href="inventory-view.php">Manage Inventory</a>
        </div>
        <button class="dropdown-btn">Suppliers
        <i class="down"></i>
        </button>
        <div class="dropdown-container">
            <a href="supplier-add.php">Add New Supplier</a>
            <a href="supplier-view.php">Manage Suppliers</a>
        </div>
        <button class="dropdown-btn">Stock Purchase
        <i class="down"></i>
        </button>
        <div class="dropdown-container">
            <a href="purchase-add.php">Add New Purchase</a>
            <a href="purchase-view.php">Manage Purchases</a>
        </div>  
        <button class="dropdown-btn">Employees
        <i class="down"></i>
        </button>
        <div class="dropdown-container">
            <a href="employee-add.php">Add New Employee</a>
            <a href="employee-view.php">Manage Employees</a>
        </div>      
        <button class="dropdown-btn">Customers
        <i class="down"></i>
        </button>
        <div class="dropdown-container">
            <a href="customer-add.php">Add New Customer</a>
            <a href="customer-view.php">Manage Customers</a>
        </div>
        <a href="sales-view.php">View Sales Invoice Details</a>
        <a href="salesitems-view.php">View Sold Products Details</a>
        <a href="pos1.php">Add New Sale</a>         
        <button class="dropdown-btn">Reports
        <i class="down"></i>
        </button>
        <div class="dropdown-container">
            <a href="stockreport.php">Medicines - Low Stock</a>
            <a href="expiryreport.php">Medicines - Soon to Expire</a>
            <a href="salesreport.php">Transactions Reports</a>             
        </div>      
    </div>

    <div class="topnav">
        <a href="logout.php">Logout</a>
    </div>
    
    <center>
    <div class="head">
    <h2> MEDICINES LOW ON STOCK(LESS THAN 50)</h2>
    </div>
    </center>

    <!-- Search Bar -->
    <input type="text" id="searchInput" onkeyup="filterTable()" placeholder="Search for medicine names...">

    <table align="right" id="table1" style="margin-right:100px;">
        <thead>
        <tr>
            <th>Medicine ID</th>
            <th>Medicine Name</th>
            <th>Quantity Available</th>
            <th>Category</th>
            <th>Price</th>
        </tr>
        </thead>
        <tbody>
        
    <?php
    
    include "config.php";
    $result=mysqli_query($conn,"CALL `STOCK`();");
    if ($result->num_rows > 0) {
    
    while($row = $result->fetch_assoc()) {

    echo "<tr>";
        echo "<td>" . $row["med_id"]. "</td>";
        echo "<td>" . $row["med_name"] . "</td>";
        echo "<td style='color:red;'>" . $row["med_qty"]. "</td>";
        echo "<td>" . $row["category"]. "</td>";
        echo "<td>" . $row["med_price"] . "</td>";
    echo "</tr>";
    }
    } 

    $conn->close();
    ?>
        </tbody>
    </table>
    
</body>

<script>
    
    var dropdown = document.getElementsByClassName("dropdown-btn");
    var i;

    for (i = 0; i < dropdown.length; i++) {
      dropdown[i].addEventListener("click", function() {
      this.classList.toggle("active");
      var dropdownContent = this.nextElementSibling;
      if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
      } else {
      dropdownContent.style.display = "block";
      }
      });
    }

    // Search filter function
    function filterTable() {
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("searchInput");
        filter = input.value.toUpperCase();
        table = document.getElementById("table1");
        tr = table.getElementsByTagName("tr");

        // Loop through all table rows, except the header (i=1)
        for (i = 1; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[1]; // Medicine Name column
            if (td) {
                txtValue = td.textContent || td.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }       
        }
    }
            
</script>

</html>
